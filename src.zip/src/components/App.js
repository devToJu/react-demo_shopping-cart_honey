import React, { Component } from 'react'
import HoneyCard from './HoneyCard'
import { honeyDatas } from '../data/honeyData'

import pic_honey from '../images/honey.png'
import pic_beeleft from '../images/beeleft.png'
import pic_beeright from '../images/beeright.png'

import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Stack from 'react-bootstrap/Stack';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form'


export class App extends Component {
    constructor(props) {
        super(props);

        this.handleAddHoney = this.handleAddHoney.bind(this);
        this.handleRemoveHoney = this.handleRemoveHoney.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

        this.state = {
            honeyCounterTotal: 0,
            priceTotal: 0,
            datas: honeyDatas
        };

    }

    handleAddHoney(id) {
        honeyDatas[id - 1].counter++;

        this.setState((prevState) => ({
            honeyCounterTotal: prevState.honeyCounterTotal + 1,
            priceTotal: prevState.priceTotal + honeyDatas[id - 1].price
        }));
    }

    handleRemoveHoney(id) {
        honeyDatas[id - 1].counter--;

        this.setState((prevState) => ({
            honeyCounterTotal: prevState.honeyCounterTotal - 1,
            priceTotal: prevState.priceTotal - honeyDatas[id - 1].price
        }));
    }

    handleSubmit(event) {
        event.preventDefault();
        console.log("Gesamtanzahl: " + this.state.honeyCounterTotal + "\nGesamtpreis: " + this.state.priceTotal);
        honeyDatas.forEach((data) => data.counter = 0);

        this.setState((prevState) => ({
            honeyCounterTotal: 0,
            priceTotal: 0
        }));
    }

    render() {
        return (
            <Form onSubmit={this.handleSubmit}>
                <br />
                <Container style={{ border: '2px solid gray', maxWidth: 500 }}>
                    <Row>
                        <Col>
                            <center>
                                <h1>Alles Honig?</h1>
                                <img alt='Blütenhonig' src={pic_honey} height={75} />
                            </center>
                        </Col>
                    </Row>
                    <hr />
                    <Row>
                        <Stack direction="horizontal">
                            <img alt='BieneLinks' src={pic_beeleft} height={75} />
                            <img className="ms-auto" alt='BieneRechts' src={pic_beeright} height={75} />
                        </Stack>
                    </Row>
                    <hr />
                    <Row>
                        {
                            honeyDatas.map((honey) => (
                                <HoneyCard key={honey.id} data={honey} addHoney={this.handleAddHoney} removeHoney={this.handleRemoveHoney} />
                            ))
                        }
                    </Row>
                    <hr />
                    <Row>
                        <span>
                            Anzahl Honige: {this.state.honeyCounterTotal}<br />
                            Gesamtsumme: {this.state.priceTotal} €
                        </span>
                    </Row>
                    <div className="d-flex flex-row-reverse" style={{ margin: '15px 0px' }}>
                        <Button type='submit' variant="success" disabled={this.state.honeyCounterTotal < 5}>
                            Bezahlen
                        </Button>
                    </div>
                </Container>
            </Form>
        )
    }
}

export default App